"""Benchmark entrypoints for maxsim."""

